#ifndef LISTADOBLEENLAZADA_H
#define LISTADOBLEENLAZADA_H


class ListaDobleEnlazada
{
public:
    ListaDobleEnlazada();
};

#endif // LISTADOBLEENLAZADA_H
