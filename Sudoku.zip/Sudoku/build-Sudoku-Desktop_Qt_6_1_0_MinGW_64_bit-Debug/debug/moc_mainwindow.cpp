/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[136];
    char stringdata0[1205];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 16), // "on_btn_1_clicked"
QT_MOC_LITERAL(28, 0), // ""
QT_MOC_LITERAL(29, 16), // "on_btn_2_clicked"
QT_MOC_LITERAL(46, 16), // "on_btn_3_clicked"
QT_MOC_LITERAL(63, 16), // "on_btn_4_clicked"
QT_MOC_LITERAL(80, 16), // "on_btn_5_clicked"
QT_MOC_LITERAL(97, 16), // "on_btn_6_clicked"
QT_MOC_LITERAL(114, 16), // "on_btn_7_clicked"
QT_MOC_LITERAL(131, 16), // "on_btn_8_clicked"
QT_MOC_LITERAL(148, 17), // "on_btn_17_clicked"
QT_MOC_LITERAL(166, 17), // "on_btn_18_clicked"
QT_MOC_LITERAL(184, 17), // "on_btn_19_clicked"
QT_MOC_LITERAL(202, 17), // "on_btn_20_clicked"
QT_MOC_LITERAL(220, 17), // "on_btn_21_clicked"
QT_MOC_LITERAL(238, 17), // "on_btn_22_clicked"
QT_MOC_LITERAL(256, 17), // "on_btn_23_clicked"
QT_MOC_LITERAL(274, 17), // "on_btn_24_clicked"
QT_MOC_LITERAL(292, 17), // "on_btn_25_clicked"
QT_MOC_LITERAL(310, 17), // "on_btn_26_clicked"
QT_MOC_LITERAL(328, 17), // "on_btn_27_clicked"
QT_MOC_LITERAL(346, 17), // "on_btn_28_clicked"
QT_MOC_LITERAL(364, 17), // "on_btn_29_clicked"
QT_MOC_LITERAL(382, 17), // "on_btn_30_clicked"
QT_MOC_LITERAL(400, 17), // "on_btn_31_clicked"
QT_MOC_LITERAL(418, 17), // "on_btn_32_clicked"
QT_MOC_LITERAL(436, 17), // "on_btn_33_clicked"
QT_MOC_LITERAL(454, 17), // "on_btn_34_clicked"
QT_MOC_LITERAL(472, 17), // "on_btn_35_clicked"
QT_MOC_LITERAL(490, 17), // "on_btn_36_clicked"
QT_MOC_LITERAL(508, 17), // "on_btn_37_clicked"
QT_MOC_LITERAL(526, 17), // "on_btn_38_clicked"
QT_MOC_LITERAL(544, 17), // "on_btn_39_clicked"
QT_MOC_LITERAL(562, 17), // "on_btn_40_clicked"
QT_MOC_LITERAL(580, 17), // "on_btn_41_clicked"
QT_MOC_LITERAL(598, 17), // "on_btn_42_clicked"
QT_MOC_LITERAL(616, 17), // "on_btn_43_clicked"
QT_MOC_LITERAL(634, 17), // "on_btn_44_clicked"
QT_MOC_LITERAL(652, 17), // "on_btn_45_clicked"
QT_MOC_LITERAL(670, 17), // "on_btn_46_clicked"
QT_MOC_LITERAL(688, 17), // "on_btn_47_clicked"
QT_MOC_LITERAL(706, 17), // "on_btn_48_clicked"
QT_MOC_LITERAL(724, 17), // "on_btn_49_clicked"
QT_MOC_LITERAL(742, 17), // "on_btn_50_clicked"
QT_MOC_LITERAL(760, 17), // "on_btn_51_clicked"
QT_MOC_LITERAL(778, 17), // "on_btn_52_clicked"
QT_MOC_LITERAL(796, 17), // "on_btn_53_clicked"
QT_MOC_LITERAL(814, 17), // "on_btn_54_clicked"
QT_MOC_LITERAL(832, 17), // "on_btn_55_clicked"
QT_MOC_LITERAL(850, 17), // "on_btn_56_clicked"
QT_MOC_LITERAL(868, 17), // "on_btn_57_clicked"
QT_MOC_LITERAL(886, 17), // "on_btn_58_clicked"
QT_MOC_LITERAL(904, 17), // "on_btn_59_clicked"
QT_MOC_LITERAL(922, 17), // "on_btn_60_clicked"
QT_MOC_LITERAL(940, 17), // "on_btn_61_clicked"
QT_MOC_LITERAL(958, 17), // "on_btn_62_clicked"
QT_MOC_LITERAL(976, 17), // "on_btn_63_clicked"
QT_MOC_LITERAL(994, 17), // "on_btn_64_clicked"
QT_MOC_LITERAL(1012, 17), // "on_btn_65_clicked"
QT_MOC_LITERAL(1030, 17), // "on_btn_66_clicked"
QT_MOC_LITERAL(1048, 17), // "on_btn_67_clicked"
QT_MOC_LITERAL(1066, 17), // "on_btn_68_clicked"
QT_MOC_LITERAL(1084, 17), // "on_btn_69_clicked"
QT_MOC_LITERAL(1102, 17), // "on_btn_70_clicked"
QT_MOC_LITERAL(1120, 17), // "on_btn_71_clicked"
QT_MOC_LITERAL(1138, 17), // "on_btn_72_clicked"
QT_MOC_LITERAL(1156, 24), // "on_btnSolucionar_clicked"
QT_MOC_LITERAL(1181, 23) // "on_btnSiguiente_clicked"

    },
    "MainWindow\0on_btn_1_clicked\0\0"
    "on_btn_2_clicked\0on_btn_3_clicked\0"
    "on_btn_4_clicked\0on_btn_5_clicked\0"
    "on_btn_6_clicked\0on_btn_7_clicked\0"
    "on_btn_8_clicked\0on_btn_17_clicked\0"
    "on_btn_18_clicked\0on_btn_19_clicked\0"
    "on_btn_20_clicked\0on_btn_21_clicked\0"
    "on_btn_22_clicked\0on_btn_23_clicked\0"
    "on_btn_24_clicked\0on_btn_25_clicked\0"
    "on_btn_26_clicked\0on_btn_27_clicked\0"
    "on_btn_28_clicked\0on_btn_29_clicked\0"
    "on_btn_30_clicked\0on_btn_31_clicked\0"
    "on_btn_32_clicked\0on_btn_33_clicked\0"
    "on_btn_34_clicked\0on_btn_35_clicked\0"
    "on_btn_36_clicked\0on_btn_37_clicked\0"
    "on_btn_38_clicked\0on_btn_39_clicked\0"
    "on_btn_40_clicked\0on_btn_41_clicked\0"
    "on_btn_42_clicked\0on_btn_43_clicked\0"
    "on_btn_44_clicked\0on_btn_45_clicked\0"
    "on_btn_46_clicked\0on_btn_47_clicked\0"
    "on_btn_48_clicked\0on_btn_49_clicked\0"
    "on_btn_50_clicked\0on_btn_51_clicked\0"
    "on_btn_52_clicked\0on_btn_53_clicked\0"
    "on_btn_54_clicked\0on_btn_55_clicked\0"
    "on_btn_56_clicked\0on_btn_57_clicked\0"
    "on_btn_58_clicked\0on_btn_59_clicked\0"
    "on_btn_60_clicked\0on_btn_61_clicked\0"
    "on_btn_62_clicked\0on_btn_63_clicked\0"
    "on_btn_64_clicked\0on_btn_65_clicked\0"
    "on_btn_66_clicked\0on_btn_67_clicked\0"
    "on_btn_68_clicked\0on_btn_69_clicked\0"
    "on_btn_70_clicked\0on_btn_71_clicked\0"
    "on_btn_72_clicked\0on_btnSolucionar_clicked\0"
    "on_btnSiguiente_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      66,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  410,    2, 0x08,    0 /* Private */,
       3,    0,  411,    2, 0x08,    1 /* Private */,
       4,    0,  412,    2, 0x08,    2 /* Private */,
       5,    0,  413,    2, 0x08,    3 /* Private */,
       6,    0,  414,    2, 0x08,    4 /* Private */,
       7,    0,  415,    2, 0x08,    5 /* Private */,
       8,    0,  416,    2, 0x08,    6 /* Private */,
       9,    0,  417,    2, 0x08,    7 /* Private */,
      10,    0,  418,    2, 0x08,    8 /* Private */,
      11,    0,  419,    2, 0x08,    9 /* Private */,
      12,    0,  420,    2, 0x08,   10 /* Private */,
      13,    0,  421,    2, 0x08,   11 /* Private */,
      14,    0,  422,    2, 0x08,   12 /* Private */,
      15,    0,  423,    2, 0x08,   13 /* Private */,
      16,    0,  424,    2, 0x08,   14 /* Private */,
      17,    0,  425,    2, 0x08,   15 /* Private */,
      18,    0,  426,    2, 0x08,   16 /* Private */,
      19,    0,  427,    2, 0x08,   17 /* Private */,
      20,    0,  428,    2, 0x08,   18 /* Private */,
      21,    0,  429,    2, 0x08,   19 /* Private */,
      22,    0,  430,    2, 0x08,   20 /* Private */,
      23,    0,  431,    2, 0x08,   21 /* Private */,
      24,    0,  432,    2, 0x08,   22 /* Private */,
      25,    0,  433,    2, 0x08,   23 /* Private */,
      26,    0,  434,    2, 0x08,   24 /* Private */,
      27,    0,  435,    2, 0x08,   25 /* Private */,
      28,    0,  436,    2, 0x08,   26 /* Private */,
      29,    0,  437,    2, 0x08,   27 /* Private */,
      30,    0,  438,    2, 0x08,   28 /* Private */,
      31,    0,  439,    2, 0x08,   29 /* Private */,
      32,    0,  440,    2, 0x08,   30 /* Private */,
      33,    0,  441,    2, 0x08,   31 /* Private */,
      34,    0,  442,    2, 0x08,   32 /* Private */,
      35,    0,  443,    2, 0x08,   33 /* Private */,
      36,    0,  444,    2, 0x08,   34 /* Private */,
      37,    0,  445,    2, 0x08,   35 /* Private */,
      38,    0,  446,    2, 0x08,   36 /* Private */,
      39,    0,  447,    2, 0x08,   37 /* Private */,
      40,    0,  448,    2, 0x08,   38 /* Private */,
      41,    0,  449,    2, 0x08,   39 /* Private */,
      42,    0,  450,    2, 0x08,   40 /* Private */,
      43,    0,  451,    2, 0x08,   41 /* Private */,
      44,    0,  452,    2, 0x08,   42 /* Private */,
      45,    0,  453,    2, 0x08,   43 /* Private */,
      46,    0,  454,    2, 0x08,   44 /* Private */,
      47,    0,  455,    2, 0x08,   45 /* Private */,
      48,    0,  456,    2, 0x08,   46 /* Private */,
      49,    0,  457,    2, 0x08,   47 /* Private */,
      50,    0,  458,    2, 0x08,   48 /* Private */,
      51,    0,  459,    2, 0x08,   49 /* Private */,
      52,    0,  460,    2, 0x08,   50 /* Private */,
      53,    0,  461,    2, 0x08,   51 /* Private */,
      54,    0,  462,    2, 0x08,   52 /* Private */,
      55,    0,  463,    2, 0x08,   53 /* Private */,
      56,    0,  464,    2, 0x08,   54 /* Private */,
      57,    0,  465,    2, 0x08,   55 /* Private */,
      58,    0,  466,    2, 0x08,   56 /* Private */,
      59,    0,  467,    2, 0x08,   57 /* Private */,
      60,    0,  468,    2, 0x08,   58 /* Private */,
      61,    0,  469,    2, 0x08,   59 /* Private */,
      62,    0,  470,    2, 0x08,   60 /* Private */,
      63,    0,  471,    2, 0x08,   61 /* Private */,
      64,    0,  472,    2, 0x08,   62 /* Private */,
      65,    0,  473,    2, 0x08,   63 /* Private */,
      66,    0,  474,    2, 0x08,   64 /* Private */,
      67,    0,  475,    2, 0x08,   65 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_btn_1_clicked(); break;
        case 1: _t->on_btn_2_clicked(); break;
        case 2: _t->on_btn_3_clicked(); break;
        case 3: _t->on_btn_4_clicked(); break;
        case 4: _t->on_btn_5_clicked(); break;
        case 5: _t->on_btn_6_clicked(); break;
        case 6: _t->on_btn_7_clicked(); break;
        case 7: _t->on_btn_8_clicked(); break;
        case 8: _t->on_btn_17_clicked(); break;
        case 9: _t->on_btn_18_clicked(); break;
        case 10: _t->on_btn_19_clicked(); break;
        case 11: _t->on_btn_20_clicked(); break;
        case 12: _t->on_btn_21_clicked(); break;
        case 13: _t->on_btn_22_clicked(); break;
        case 14: _t->on_btn_23_clicked(); break;
        case 15: _t->on_btn_24_clicked(); break;
        case 16: _t->on_btn_25_clicked(); break;
        case 17: _t->on_btn_26_clicked(); break;
        case 18: _t->on_btn_27_clicked(); break;
        case 19: _t->on_btn_28_clicked(); break;
        case 20: _t->on_btn_29_clicked(); break;
        case 21: _t->on_btn_30_clicked(); break;
        case 22: _t->on_btn_31_clicked(); break;
        case 23: _t->on_btn_32_clicked(); break;
        case 24: _t->on_btn_33_clicked(); break;
        case 25: _t->on_btn_34_clicked(); break;
        case 26: _t->on_btn_35_clicked(); break;
        case 27: _t->on_btn_36_clicked(); break;
        case 28: _t->on_btn_37_clicked(); break;
        case 29: _t->on_btn_38_clicked(); break;
        case 30: _t->on_btn_39_clicked(); break;
        case 31: _t->on_btn_40_clicked(); break;
        case 32: _t->on_btn_41_clicked(); break;
        case 33: _t->on_btn_42_clicked(); break;
        case 34: _t->on_btn_43_clicked(); break;
        case 35: _t->on_btn_44_clicked(); break;
        case 36: _t->on_btn_45_clicked(); break;
        case 37: _t->on_btn_46_clicked(); break;
        case 38: _t->on_btn_47_clicked(); break;
        case 39: _t->on_btn_48_clicked(); break;
        case 40: _t->on_btn_49_clicked(); break;
        case 41: _t->on_btn_50_clicked(); break;
        case 42: _t->on_btn_51_clicked(); break;
        case 43: _t->on_btn_52_clicked(); break;
        case 44: _t->on_btn_53_clicked(); break;
        case 45: _t->on_btn_54_clicked(); break;
        case 46: _t->on_btn_55_clicked(); break;
        case 47: _t->on_btn_56_clicked(); break;
        case 48: _t->on_btn_57_clicked(); break;
        case 49: _t->on_btn_58_clicked(); break;
        case 50: _t->on_btn_59_clicked(); break;
        case 51: _t->on_btn_60_clicked(); break;
        case 52: _t->on_btn_61_clicked(); break;
        case 53: _t->on_btn_62_clicked(); break;
        case 54: _t->on_btn_63_clicked(); break;
        case 55: _t->on_btn_64_clicked(); break;
        case 56: _t->on_btn_65_clicked(); break;
        case 57: _t->on_btn_66_clicked(); break;
        case 58: _t->on_btn_67_clicked(); break;
        case 59: _t->on_btn_68_clicked(); break;
        case 60: _t->on_btn_69_clicked(); break;
        case 61: _t->on_btn_70_clicked(); break;
        case 62: _t->on_btn_71_clicked(); break;
        case 63: _t->on_btn_72_clicked(); break;
        case 64: _t->on_btnSolucionar_clicked(); break;
        case 65: _t->on_btnSiguiente_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t

, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 66)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 66;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 66)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 66;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
