#ifndef LISTASIMPLE_H
#define LISTASIMPLE_H
#include "nodo.h"
#include "listaaristas.h"

/*
struct ListaSimple {

       // solo con pN es suficiente
       Nodo *primerNodo, *ultimoNodo;

       ListaSimple()
       {
           primerNodo = ultimoNodo = NULL;
       }

       // encabezados de funcion
       void insertarAlInicio (int dato);
       Nodo* borrarAlInicio(void);
       void imprimir(void);
       void insertarAlFinal(int codigo, int dato);
       void insertarAlFinal(Nodo*);
       Nodo* borrarAlFinal(void);
       Nodo* buscar (int dato);//
       int largo (void);//
       int largoRec (void);
       int largo_aux(Nodo*);
       void insertarAlFinalConRecorrido(int dato);//
       bool vacia(void);
       ListaSimple* retornaNuevaListaInvertida(void);//
       void insertarEnPosicion(int dato, int pos);
       void borrarEnPosicion(int pos);
       int posicion (int);

       void encolar(int);
       Nodo* desencolar();
};

*/

#endif // LISTASIMPLE_H
